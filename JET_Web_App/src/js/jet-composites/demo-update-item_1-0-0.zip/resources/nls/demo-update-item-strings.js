/**
  Copyright (c) 2015, 2026, Oracle and/or its affiliates.
  Licensed under The Universal Permissive License (UPL), Version 1.0
  as shown at https://oss.oracle.com/licenses/upl/

*/
define({
 "root": {
    "demo-update-item" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
 },
});